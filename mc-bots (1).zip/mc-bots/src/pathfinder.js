// mineflayer-pathfinder ist CommonJS; hier zentral als ESM-Exporte bereitgestellt.
import pathfinderPkg from 'mineflayer-pathfinder'

export const { pathfinder, Movements, goals } = pathfinderPkg
