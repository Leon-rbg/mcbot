const COLORS = ['\x1b[36m', '\x1b[32m', '\x1b[33m', '\x1b[35m', '\x1b[34m', '\x1b[91m', '\x1b[92m', '\x1b[93m', '\x1b[95m', '\x1b[96m']
const RESET = '\x1b[0m'

let colorIndex = 0

export function createLogger (name) {
  const color = COLORS[colorIndex++ % COLORS.length]
  const tag = `${color}[${name}]${RESET}`
  const stamp = () => new Date().toLocaleTimeString('de-DE')
  return {
    info: (...args) => console.log(stamp(), tag, ...args),
    warn: (...args) => console.warn(stamp(), tag, '\x1b[33mWARN\x1b[0m', ...args),
    error: (...args) => console.error(stamp(), tag, '\x1b[31mFEHLER\x1b[0m', ...args)
  }
}
