import { goals, Movements } from './pathfinder.js'
import {
  countItem,
  execContext,
  findBlock,
  findBlocks,
  goTo,
  goToBlock,
  inventoryIsFull,
  itemByName,
  sleep,
  waitUntil,
  withTimeout
} from './utils.js'

/** Standard-Bewegungsprofil: darf graben, aber keine wertvollen Bloecke zerstoeren. */
export function defaultMovements (bot) {
  const movements = new Movements(bot)
  movements.canDig = true
  movements.allow1by1towers = true
  movements.allowParkour = true
  movements.allowSprinting = true
  const avoid = ['chest', 'trapped_chest', 'furnace', 'crafting_table', 'ender_chest', 'barrel', 'bed']
  for (const name of avoid) {
    const block = bot.registry.blocksByName[name]
    if (block) movements.blocksToAvoid.add(block.id)
  }
  return movements
}

export async function gotoPosition (bot, position, range = 1) {
  return goTo(bot, position, range)
}

export async function followPlayer (bot, username, distance = 3) {
  const player = bot.players[username]
  if (!player || !player.entity) throw new Error(`Spieler ${username} nicht in Sichtweite`)
  bot.pathfinder.setGoal(new goals.GoalFollow(player.entity, distance), true)
}

export function stopAll (bot, force = false) {
  if (!force && bot.state?.commandRunning && execContext.getStore()?.command !== true) return
  bot.pathfinder.setGoal(null)
  if (bot.pvp) bot.pvp.stop()
  if (bot.collectBlock) bot.collectBlock.cancelTask?.()
  bot.clearControlStates()
}

/** Wirft einen Fehler, wenn gerade ein manueller Befehl Vorrang hat. */
function assertNoCommand (bot) {
  if (bot.state?.commandRunning && execContext.getStore()?.command !== true) {
    throw new Error('Manueller Befehl laeuft - Rolle pausiert')
  }
}

/** Gräbt einen Block ab und sammelt die Drops ein. */
export async function digBlock (bot, block) {
  if (!block) return false
  assertNoCommand(bot)
  try {
    if (bot.tool) await bot.tool.equipForBlock(block, { requireHarvest: true })
  } catch {}
  if (!bot.canDigBlock(block)) {
    await goToBlock(bot, block, 2)
  }
  await bot.collectBlock.collect(block, { ignoreNoPath: true })
  return true
}

/** Baut die angegebene Menge eines Blocktyps ab. */
export async function mineBlocks (bot, names, amount = 1, searchRadius = 48, onProgress = () => {}) {
  let mined = 0
  while (mined < amount) {
    assertNoCommand(bot)
    if (inventoryIsFull(bot)) return { mined, reason: 'inventar_voll' }
    const block = findBlock(bot, names, searchRadius)
    if (!block) return { mined, reason: 'nichts_gefunden' }
    try {
      await digBlock(bot, block)
      mined++
      onProgress(mined, block)
    } catch (err) {
      if (String(err.message).includes('Zeitueberschreitung')) return { mined, reason: 'timeout' }
      await sleep(500)
    }
  }
  return { mined, reason: 'fertig' }
}

const LOGS = [
  'oak_log', 'birch_log', 'spruce_log', 'jungle_log', 'acacia_log', 'dark_oak_log',
  'mangrove_log', 'cherry_log', 'pale_oak_log'
]

const SAPLINGS = {
  oak_log: 'oak_sapling',
  birch_log: 'birch_sapling',
  spruce_log: 'spruce_sapling',
  jungle_log: 'jungle_sapling',
  acacia_log: 'acacia_sapling',
  dark_oak_log: 'dark_oak_sapling',
  cherry_log: 'cherry_sapling',
  pale_oak_log: 'pale_oak_sapling'
}

/** Faellt einen kompletten Baum und pflanzt optional einen Setzling nach. */
export async function chopTree (bot, searchRadius = 64, replant = true) {
  const base = findBlock(bot, LOGS, searchRadius)
  if (!base) return { chopped: 0, reason: 'kein_baum' }
  const logName = base.name
  const groundPos = base.position.clone()
  let chopped = 0

  await goToBlock(bot, base, 2).catch(() => {})

  // Stamm von unten nach oben abbauen.
  for (let y = 0; y < 24; y++) {
    const pos = groundPos.offset(0, y, 0)
    const block = bot.blockAt(pos)
    if (!block || !LOGS.includes(block.name)) break
    try {
      await digBlock(bot, block)
      chopped++
    } catch {
      break
    }
  }

  // Umliegende Staemme (dicke Baeume) mitnehmen.
  const nearby = findBlocks(bot, LOGS, 6, 16)
  for (const block of nearby) {
    if (block.position.distanceTo(groundPos) > 6) continue
    try {
      await digBlock(bot, block)
      chopped++
    } catch {}
  }

  if (replant) await plantSapling(bot, groundPos, SAPLINGS[logName])
  return { chopped, reason: 'fertig' }
}

async function plantSapling (bot, position, saplingName) {
  if (!saplingName) return false
  const sapling = itemByName(bot, saplingName)
  if (!sapling) return false
  const ground = bot.blockAt(position.offset(0, -1, 0))
  if (!ground || !['dirt', 'grass_block', 'podzol', 'rooted_dirt', 'moss_block', 'mud'].includes(ground.name)) return false
  try {
    await goTo(bot, position, 2)
    await bot.equip(sapling, 'hand')
    await bot.placeBlock(ground, { x: 0, y: 1, z: 0 })
    return true
  } catch {
    return false
  }
}

const CROPS = {
  wheat: { seed: 'wheat_seeds', ripe: 7 },
  carrots: { seed: 'carrot', ripe: 7 },
  potatoes: { seed: 'potato', ripe: 7 },
  beetroots: { seed: 'beetroot_seeds', ripe: 3 },
  nether_wart: { seed: 'nether_wart', ripe: 3 }
}

export function isRipe (block) {
  const crop = CROPS[block.name]
  if (!crop) return false
  const age = block.getProperties?.().age
  return age !== undefined && Number(age) >= crop.ripe
}

/** Erntet reife Feldfruechte und saet neu aus. */
export async function harvestCrops (bot, cropNames = Object.keys(CROPS), searchRadius = 32, replant = true) {
  const blocks = findBlocks(bot, cropNames, searchRadius, 64).filter(isRipe)
  if (blocks.length === 0) return { harvested: 0, reason: 'nichts_reif' }
  let harvested = 0
  for (const block of blocks) {
    if (inventoryIsFull(bot)) break
    try {
      await goToBlock(bot, block, 2)
      const farmland = bot.blockAt(block.position.offset(0, -1, 0))
      await bot.dig(block)
      harvested++
      if (replant) {
        const seedName = CROPS[block.name]?.seed
        const seed = seedName ? itemByName(bot, seedName) : null
        if (seed && farmland && farmland.name === 'farmland') {
          await bot.equip(seed, 'hand')
          await bot.placeBlock(farmland, { x: 0, y: 1, z: 0 }).catch(() => {})
        }
      }
    } catch {}
  }
  return { harvested, reason: 'fertig' }
}

/** Stellt einen Gegenstand her (nutzt automatisch eine Werkbank in der Naehe). */
export async function craftItem (bot, itemName, count = 1) {
  const item = bot.registry.itemsByName[itemName]
  if (!item) throw new Error(`Unbekannter Gegenstand: ${itemName}`)

  let table = findBlock(bot, 'crafting_table', 32)
  let recipes = bot.recipesFor(item.id, null, count, table)
  if (recipes.length === 0 && !table) {
    const tableItem = itemByName(bot, 'crafting_table')
    if (tableItem) {
      table = await placeBlockNearby(bot, 'crafting_table')
      recipes = bot.recipesFor(item.id, null, count, table)
    }
  }
  if (recipes.length === 0) recipes = bot.recipesFor(item.id, null, count, null)
  if (recipes.length === 0) throw new Error(`Kein passendes Rezept oder Material fuer ${itemName}`)

  if (table) await goToBlock(bot, table, 3).catch(() => {})
  await bot.craft(recipes[0], count, table ?? undefined)
  return count
}

/** Setzt einen Block aus dem Inventar auf den Boden neben dem Bot. */
export async function placeBlockNearby (bot, itemName) {
  const item = itemByName(bot, itemName)
  if (!item) throw new Error(`${itemName} nicht im Inventar`)
  await bot.equip(item, 'hand')
  const offsets = [[1, -1, 0], [-1, -1, 0], [0, -1, 1], [0, -1, -1], [1, -1, 1], [-1, -1, -1]]
  for (const [dx, dy, dz] of offsets) {
    const reference = bot.blockAt(bot.entity.position.offset(dx, dy, dz))
    const target = bot.blockAt(bot.entity.position.offset(dx, dy + 1, dz))
    if (!reference || reference.name === 'air' || !target || target.name !== 'air') continue
    try {
      await bot.placeBlock(reference, { x: 0, y: 1, z: 0 })
      return bot.blockAt(bot.entity.position.offset(dx, dy + 1, dz))
    } catch {}
  }
  throw new Error(`Konnte ${itemName} nicht platzieren`)
}

const CONTAINERS = ['chest', 'trapped_chest', 'barrel', 'ender_chest', 'shulker_box']

/** Legt Gegenstaende in die naechste Truhe (alles ausser keep-Liste). */
export async function depositToChest (bot, keep = [], searchRadius = 64) {
  const chestBlock = findBlock(bot, CONTAINERS, searchRadius)
  if (!chestBlock) return { deposited: 0, reason: 'keine_truhe' }
  await goToBlock(bot, chestBlock, 2)
  const chest = await bot.openContainer(chestBlock)
  let deposited = 0
  try {
    for (const item of bot.inventory.items()) {
      if (keep.includes(item.name)) continue
      try {
        await chest.deposit(item.type, null, item.count)
        deposited += item.count
      } catch {}
    }
  } finally {
    chest.close()
  }
  return { deposited, reason: 'fertig' }
}

/** Holt Gegenstaende aus der naechsten Truhe. */
export async function withdrawFromChest (bot, itemName, count = 1, searchRadius = 64) {
  const chestBlock = findBlock(bot, CONTAINERS, searchRadius)
  if (!chestBlock) return { withdrawn: 0, reason: 'keine_truhe' }
  await goToBlock(bot, chestBlock, 2)
  const chest = await bot.openContainer(chestBlock)
  let withdrawn = 0
  try {
    const item = chest.containerItems().find((entry) => entry.name === itemName)
    if (item) {
      await chest.withdraw(item.type, null, Math.min(count, item.count))
      withdrawn = Math.min(count, item.count)
    }
  } finally {
    chest.close()
  }
  return { withdrawn, reason: withdrawn > 0 ? 'fertig' : 'nicht_gefunden' }
}

/** Schmelzt Gegenstaende in einem Ofen. */
export async function smelt (bot, inputName, fuelName = 'coal', count = 1) {
  const furnaceBlock = findBlock(bot, ['furnace', 'blast_furnace', 'smoker'], 48)
  if (!furnaceBlock) throw new Error('Kein Ofen in der Naehe')
  await goToBlock(bot, furnaceBlock, 2)
  const furnace = await bot.openFurnace(furnaceBlock)
  try {
    const input = itemByName(bot, inputName)
    const fuel = itemByName(bot, fuelName)
    if (!input) throw new Error(`${inputName} nicht im Inventar`)
    if (!fuel) throw new Error(`Kein Brennstoff (${fuelName})`)
    await furnace.putFuel(fuel.type, null, Math.max(1, Math.ceil(count / 8)))
    await furnace.putInput(input.type, null, Math.min(count, input.count))
    await waitUntil(() => furnace.outputItem() && furnace.outputItem().count >= Math.min(count, input.count), 60000, 1000)
    const output = furnace.outputItem()
    if (output) await furnace.takeOutput()
    return output ? output.count : 0
  } finally {
    furnace.close()
  }
}

/** Sucht ein Bett und schlaeft, wenn es Nacht ist. */
export async function sleepInBed (bot) {
  if (!bot.time || (bot.time.timeOfDay < 12541 && !bot.isRaining)) return 'nicht_noetig'
  const bed = bot.findBlock({ matching: (block) => Boolean(block) && bot.isABed(block), maxDistance: 32 })
  if (!bed) return 'kein_bett'
  await goToBlock(bot, bed, 2)
  try {
    await bot.sleep(bed)
    return 'schlaeft'
  } catch (err) {
    return `fehlgeschlagen: ${err.message}`
  }
}

/** Angeln bis eine bestimmte Anzahl Fische gefangen wurde. */
export async function fish (bot, times = 1) {
  const rod = itemByName(bot, 'fishing_rod')
  if (!rod) throw new Error('Keine Angel im Inventar')
  await bot.equip(rod, 'hand')
  let caught = 0
  for (let i = 0; i < times; i++) {
    try {
      await withTimeout(bot.fish(), 90000, 'Angeln')
      caught++
    } catch {
      await sleep(1000)
    }
  }
  return caught
}

export async function attackEntity (bot, entity) {
  if (!entity) throw new Error('Kein Ziel')
  bot.pvp.attack(entity)
}

export async function tossItem (bot, itemName, count = null) {
  const item = itemByName(bot, itemName)
  if (!item) throw new Error(`${itemName} nicht im Inventar`)
  await bot.toss(item.type, null, count ?? countItem(bot, itemName))
}

/** Baut eine einfache Struktur aus einem Material (hut | wall | tower | platform). */
export async function build (bot, blueprint = 'hut', material = 'oak_planks', origin = null) {
  const start = (origin ?? bot.entity.position.floored()).offset(2, 0, 0)
  const positions = blueprintPositions(blueprint, start)
  let placed = 0
  for (const pos of positions) {
    const item = itemByName(bot, material)
    if (!item) return { placed, reason: `kein_material_${material}` }
    const existing = bot.blockAt(pos)
    if (existing && existing.name !== 'air') continue
    const support = findSupport(bot, pos)
    if (!support) continue
    try {
      await goTo(bot, pos, 3)
      await bot.equip(item, 'hand')
      await bot.placeBlock(support.block, support.face)
      placed++
      await sleep(120)
    } catch {}
  }
  return { placed, reason: 'fertig' }
}

function findSupport (bot, pos) {
  const faces = [
    { offset: [0, -1, 0], face: { x: 0, y: 1, z: 0 } },
    { offset: [0, 1, 0], face: { x: 0, y: -1, z: 0 } },
    { offset: [1, 0, 0], face: { x: -1, y: 0, z: 0 } },
    { offset: [-1, 0, 0], face: { x: 1, y: 0, z: 0 } },
    { offset: [0, 0, 1], face: { x: 0, y: 0, z: -1 } },
    { offset: [0, 0, -1], face: { x: 0, y: 0, z: 1 } }
  ]
  for (const entry of faces) {
    const block = bot.blockAt(pos.offset(...entry.offset))
    if (block && block.name !== 'air' && block.boundingBox === 'block') {
      return { block, face: entry.face }
    }
  }
  return null
}

function blueprintPositions (blueprint, start) {
  const positions = []
  const push = (x, y, z) => positions.push(start.offset(x, y, z))
  if (blueprint === 'wall') {
    for (let x = 0; x < 7; x++) for (let y = 0; y < 3; y++) push(x, y, 0)
  } else if (blueprint === 'tower') {
    for (let y = 0; y < 10; y++) push(0, y, 0)
  } else if (blueprint === 'platform') {
    for (let x = 0; x < 5; x++) for (let z = 0; z < 5; z++) push(x, 0, z)
  } else {
    // hut: 5x5 Huette mit Tuerluecke und Flachdach
    const size = 5
    for (let y = 0; y < 3; y++) {
      for (let i = 0; i < size; i++) {
        push(i, y, 0)
        push(i, y, size - 1)
        push(0, y, i)
        push(size - 1, y, i)
      }
    }
    for (let x = 0; x < size; x++) for (let z = 0; z < size; z++) push(x, 3, z)
    // Tuerluecke wieder entfernen
    return positions.filter((pos) => !(pos.equals(start.offset(2, 0, 0)) || pos.equals(start.offset(2, 1, 0))))
  }
  return positions
}

export const skills = {
  attackEntity,
  build,
  chopTree,
  craftItem,
  defaultMovements,
  depositToChest,
  digBlock,
  fish,
  followPlayer,
  gotoPosition,
  harvestCrops,
  mineBlocks,
  placeBlockNearby,
  sleepInBed,
  smelt,
  stopAll,
  tossItem,
  withdrawFromChest
}
