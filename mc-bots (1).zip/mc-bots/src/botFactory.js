import mineflayer from 'mineflayer'
import { pathfinder, goals } from './pathfinder.js'
import pvp from 'mineflayer-pvp'
import collectBlock from 'mineflayer-collectblock'
import toolPlugin from 'mineflayer-tool'
import armorManager from 'mineflayer-armor-manager'
import { loader as autoEat } from 'mineflayer-auto-eat'
import webInventory from 'mineflayer-web-inventory'
import { createLogger } from './logger.js'
import { handleCommand } from './commands.js'
import { getRole } from './roles/index.js'
import { defaultMovements, stopAll } from './skills.js'
import net from 'node:net'
import { gotoGoal, randomInt, sleep, withTimeout } from './utils.js'

/**
 * Erstellt einen Bot inklusive Plugins, Rollen-Schleife, Chat-Steuerung
 * und automatischem Reconnect.
 */
export function createManagedBot (botConfig, appConfig) {
  const log = createLogger(botConfig.username)
  const manager = {
    username: botConfig.username,
    role: botConfig.role ?? 'idle',
    options: botConfig.options ?? {},
    bot: null,
    reconnectAttempts: 0,
    stopped: false,
    log,
    start () { connect() },
    stop () {
      manager.stopped = true
      manager.bot?.quit('Beendet')
    }
  }

  function connect () {
    if (manager.stopped) return

    const bot = mineflayer.createBot({
      host: appConfig.server.host,
      port: appConfig.server.port,
      username: botConfig.username,
      auth: appConfig.server.auth ?? 'offline',
      version: appConfig.server.version,
      hideErrors: false,
      checkTimeoutInterval: 60000,
      viewDistance: appConfig.server.viewDistance ?? 'tiny'
    })

    manager.bot = bot
    if (process.env.DEBUG_GOAL) {
      bot.once('spawn', () => {
        const original = bot.pathfinder.setGoal.bind(bot.pathfinder)
        bot.pathfinder.setGoal = (goal, dynamic) => {
          console.log(`[GOAL] ${bot.username} -> ${goal?.constructor?.name ?? 'null'}\n${new Error().stack.split('\n').slice(1, 12).join('\n')}`)
          return original(goal, dynamic)
        }
      })
    }
    attachState(bot, manager, appConfig)
    loadPlugins(bot)
    attachEvents(bot, manager, appConfig, connect)
  }

  return manager
}

function attachState (bot, manager, appConfig) {
  bot.state = {
    master: appConfig.master,
    allowPublicCommands: appConfig.allowPublicCommands === true,
    chatPrefix: appConfig.chatPrefix ?? '!',
    roleName: manager.role,
    manual: false,
    commandRunning: 0,
    shuttingDown: false,
    waypoints: {},
    log: manager.log
  }

  bot.say = (message) => {
    for (const chunk of chunkMessage(message)) {
      try {
        bot.chat(chunk)
      } catch {}
    }
  }

  bot.whisperOrSay = (target, message) => {
    if (!target || !bot.players[target]) return bot.say(message)
    for (const chunk of chunkMessage(message)) {
      try {
        bot.whisper(target, chunk)
      } catch {}
    }
  }

  /** Laeuft an eine zufaellige Position im Umkreis. */
  bot.wanderRandomly = async (radius = 32) => {
    const pos = bot.entity.position
    const angle = Math.random() * Math.PI * 2
    const target = pos.offset(Math.cos(angle) * radius, 0, Math.sin(angle) * radius).floored()
    await gotoGoal(bot, new goals.GoalNearXZ(target.x, target.z, 4), 45000).catch(() => {})
  }

  bot.setRole = async (name) => {
    stopAll(bot)
    manager.role = name
    bot.state.roleName = name
    bot.state.manual = false
    bot.roleContext = createRoleContext(bot, manager)
    const role = getRole(name)
    if (role.init) await role.init(bot, bot.roleContext)
    manager.log.info(`Rolle gesetzt: ${name} (${role.description})`)
  }
}

/** Zerlegt lange Antworten, damit der Server sie nicht abschneidet. */
function chunkMessage (message, size = 180) {
  const text = String(message)
  const chunks = []
  let rest = text
  while (rest.length > size) {
    const cut = rest.lastIndexOf(' ', size)
    const index = cut > size / 2 ? cut : size
    chunks.push(rest.slice(0, index))
    rest = rest.slice(index).trimStart()
  }
  if (rest.length > 0) chunks.push(rest)
  return chunks
}

function createRoleContext (bot, manager) {
  return {
    options: { ...manager.options, ...bot.state.options },
    memory: {},
    log: manager.log
  }
}

function loadPlugins (bot) {
  bot.loadPlugin(pathfinder)
  bot.loadPlugin(pvp.plugin)
  bot.loadPlugin(collectBlock.plugin)
  bot.loadPlugin(toolPlugin.plugin)
  bot.loadPlugin(armorManager)
  bot.loadPlugin(autoEat)
}

function attachEvents (bot, manager, appConfig, reconnect) {
  const log = manager.log

  bot.once('spawn', async () => {
    manager.reconnectAttempts = 0
    log.info(`Verbunden mit ${appConfig.server.host}:${appConfig.server.port} (${bot.version})`)

    bot.pathfinder.setMovements(defaultMovements(bot))

    bot.autoEat.setOpts({
      priority: 'foodPoints',
      minHunger: 15,
      bannedFood: ['rotten_flesh', 'spider_eye', 'poisonous_potato', 'pufferfish', 'chicken', 'suspicious_stew']
    })
    bot.autoEat.enableAuto()
    bot.autoEat.on('eatFail', (err) => log.warn(`Essen fehlgeschlagen: ${err.message}`))

    if (appConfig.webInventory?.enabled && manager.webPort) {
      const port = await freePort(manager.webPort)
      if (port) {
        webInventory(bot, { port, startOnLoad: true })
        log.info(`Web-Inventar: http://localhost:${port}`)
      } else {
        log.warn('Kein freier Port fuer das Web-Inventar gefunden.')
      }
    }

    await bot.setRole(manager.role)
    startAntiAfk(bot)
    startAutoSleep(bot)
    runRoleLoop(bot, manager)
  })

  bot.on('chat', (username, message) => {
    if (username === bot.username) return
    const prefix = bot.state.chatPrefix
    if (!message.startsWith(prefix)) return
    const command = message.slice(prefix.length)
    const targeted = command.match(/^@(\S+)\s+(.*)$/)
    if (targeted) {
      if (targeted[1].toLowerCase() !== bot.username.toLowerCase() && targeted[1] !== 'alle') return
      handleCommand(bot, username, targeted[2])
      return
    }
    handleCommand(bot, username, command)
  })

  bot.on('whisper', (username, message) => {
    if (username === bot.username) return
    const prefix = bot.state.chatPrefix
    handleCommand(bot, username, message.startsWith(prefix) ? message.slice(prefix.length) : message)
  })

  bot.on('death', () => {
    log.warn('Gestorben - respawne und mache weiter.')
    bot.state.manual = false
  })

  bot.on('health', () => {
    if (bot.health < 8 && bot.pvp?.target) {
      log.warn('Wenig Leben - ziehe mich zurueck.')
      bot.pvp.stop()
      bot.wanderRandomly(16)
    }
  })

  bot.on('kicked', (reason) => log.warn('Gekickt:', typeof reason === 'string' ? reason : JSON.stringify(reason)))
  bot.on('error', (err) => log.error(err.message))

  bot.on('end', (reason) => {
    log.warn(`Verbindung beendet (${reason}).`)
    if (manager.stopped || bot.state?.shuttingDown || !appConfig.reconnect?.enabled) return
    const base = appConfig.reconnect.delayMs ?? 10000
    const max = appConfig.reconnect.maxDelayMs ?? 120000
    const delay = Math.min(base * Math.pow(1.5, manager.reconnectAttempts++), max)
    log.info(`Neuer Verbindungsversuch in ${Math.round(delay / 1000)}s ...`)
    setTimeout(reconnect, delay)
  })
}

/** Sucht ab startPort den naechsten freien TCP-Port. */
async function freePort (startPort, tries = 20) {
  for (let port = startPort; port < startPort + tries; port++) {
    const available = await new Promise((resolve) => {
      const server = net.createServer()
      server.once('error', () => resolve(false))
      server.once('listening', () => server.close(() => resolve(true)))
      server.listen(port)
    })
    if (available) return port
  }
  return null
}

/** Haelt den Bot aktiv, damit AFK-Kicks ausbleiben. */
function startAntiAfk (bot) {
  const interval = setInterval(() => {
    if (!bot.entity || bot.state.manual || bot.pathfinder.isMoving()) return
    bot.look(bot.entity.yaw + (Math.random() - 0.5), bot.entity.pitch * 0.9, false).catch(() => {})
    bot.setControlState('jump', true)
    setTimeout(() => bot.setControlState('jump', false), 300)
  }, randomInt(30000, 60000))
  bot.once('end', () => clearInterval(interval))
}

/** Legt den Bot nachts in ein Bett, falls eines in der Naehe ist. */
function startAutoSleep (bot) {
  const interval = setInterval(async () => {
    if (!bot.entity || bot.isSleeping || bot.state.manual) return
    if (!bot.time || bot.time.timeOfDay < 12541) return
    const bed = bot.findBlock({ matching: (block) => Boolean(block) && bot.isABed(block), maxDistance: 16 })
    if (!bed) return
    try {
      await gotoGoal(bot, new goals.GoalNear(bed.position.x, bed.position.y, bed.position.z, 2), 30000)
      await bot.sleep(bed)
      bot.state.log.info('Schlafe bis zum Morgen.')
    } catch {}
  }, 30000)
  bot.once('end', () => clearInterval(interval))
}

/** Fuehrt die Rolle in einer Endlosschleife aus, solange kein manueller Befehl laeuft. */
async function runRoleLoop (bot, manager) {
  while (bot.entity && !manager.stopped) {
    try {
      if (bot.state.manual || bot.state.commandRunning || bot.isSleeping || bot.autoEat?.isEating) {
        await sleep(1000)
        continue
      }
      const role = getRole(bot.state.roleName)
      await withTimeout(role.tick(bot, bot.roleContext), manager.options.tickTimeoutMs ?? 240000, `Rolle ${role.name}`)
    } catch (err) {
      manager.log.error(`Rolle ${bot.state.roleName}:`, process.env.DEBUG_STACK ? err.stack : err.message)
      stopAll(bot)
      await sleep(3000)
    }
    await sleep(250)
  }
}
