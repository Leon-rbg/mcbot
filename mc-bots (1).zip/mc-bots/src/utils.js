import { goals } from './pathfinder.js'
import Vec3 from 'vec3'
import { AsyncLocalStorage } from 'node:async_hooks'

/** Markiert, ob der aktuelle Code aus einem manuellen Chat-Befehl heraus laeuft. */
export const execContext = new AsyncLocalStorage()

export const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

export function randomInt (min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

/** Laeuft zu einem Pathfinder-Ziel und bricht nach timeoutMs sauber ab. */
export async function gotoGoal (bot, goal, timeoutMs = 60000, retries = 1) {
  const fromCommand = execContext.getStore()?.command === true
  if (!fromCommand && bot.state?.commandRunning) {
    throw new Error('Manueller Befehl laeuft - Rolle pausiert')
  }
  for (let attempt = 0; ; attempt++) {
    try {
      await withTimeout(bot.pathfinder.goto(goal), timeoutMs, 'Wegfindung')
      return
    } catch (err) {
      // Nur aufraeumen, wenn kein anderer (z. B. ein manueller Befehl) das Ziel uebernommen hat.
      if (fromCommand || !bot.state?.commandRunning) bot.pathfinder.setGoal(null)
      const interrupted = /goal was changed|path was stopped/i.test(err.message)
      if (!interrupted || attempt >= retries) throw err
      await sleep(500)
    }
  }
}

/** Laeuft zu einer Position und bricht nach timeoutMs ab. */
export async function goTo (bot, position, range = 1, timeoutMs = 60000) {
  return gotoGoal(bot, new goals.GoalNear(position.x, position.y, position.z, range), timeoutMs)
}

export async function goToBlock (bot, block, range = 2, timeoutMs = 60000) {
  return goTo(bot, block.position, range, timeoutMs)
}

export function withTimeout (promise, ms, label = 'Aktion') {
  let timer
  const timeout = new Promise((_resolve, reject) => {
    timer = setTimeout(() => reject(new Error(`${label}: Zeitueberschreitung nach ${ms} ms`)), ms)
  })
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer))
}

/** Sucht den naechsten Block aus einer Namensliste. */
export function findBlock (bot, names, maxDistance = 48) {
  const ids = blockIds(bot, names)
  if (ids.length === 0) return null
  return bot.findBlock({ matching: ids, maxDistance })
}

export function findBlocks (bot, names, maxDistance = 48, count = 16) {
  const ids = blockIds(bot, names)
  if (ids.length === 0) return []
  return bot.findBlocks({ matching: ids, maxDistance, count })
    .map((pos) => bot.blockAt(pos))
    .filter(Boolean)
}

export function blockIds (bot, names) {
  const list = Array.isArray(names) ? names : [names]
  return list
    .map((name) => bot.registry.blocksByName[name])
    .filter(Boolean)
    .map((block) => block.id)
}

export function itemByName (bot, name) {
  return bot.inventory.items().find((item) => item.name === name)
}

export function countItem (bot, name) {
  return bot.inventory.items()
    .filter((item) => item.name === name)
    .reduce((sum, item) => sum + item.count, 0)
}

export function inventoryIsFull (bot) {
  return bot.inventory.emptySlotCount() === 0
}

export function describeInventory (bot) {
  const items = bot.inventory.items()
  if (items.length === 0) return 'Inventar ist leer'
  return items.map((item) => `${item.name} x${item.count}`).join(', ')
}

export function nearestPlayerEntity (bot, username) {
  const player = bot.players[username]
  return player && player.entity ? player.entity : null
}

export function vec (x, y, z) {
  return new Vec3(x, y, z)
}

/** Wartet bis eine Bedingung wahr ist (oder Timeout). */
export async function waitUntil (predicate, timeoutMs = 10000, intervalMs = 200) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    if (predicate()) return true
    await sleep(intervalMs)
  }
  return false
}
