import { goals } from '../pathfinder.js'
import { sleep } from '../utils.js'

export default {
  name: 'follower',
  description: 'Folgt dem Besitzer, verteidigt ihn und sammelt seine Drops ein',

  async tick (bot, ctx) {
    const master = bot.state.master
    const player = bot.players[master]

    if (!player || !player.entity) {
      if (!ctx.memory.warned) {
        ctx.log.info(`Warte auf ${master} ...`)
        ctx.memory.warned = true
      }
      await sleep(3000)
      return
    }
    ctx.memory.warned = false

    const distance = ctx.options.distance ?? 3
    const goal = new goals.GoalFollow(player.entity, distance)
    if (!(bot.pathfinder.goal instanceof goals.GoalFollow)) {
      bot.pathfinder.setGoal(goal, true)
    }

    // Feinde nahe am Besitzer angreifen.
    const threat = bot.nearestEntity((entity) =>
      entity.type === 'hostile' &&
      entity.position.distanceTo(player.entity.position) < (ctx.options.defendRadius ?? 8))
    if (threat && bot.pvp.target !== threat) {
      ctx.log.info(`Verteidige ${master} gegen ${threat.name}.`)
      bot.pvp.attack(threat)
    }

    await sleep(1000)
  }
}
