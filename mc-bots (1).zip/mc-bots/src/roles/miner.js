import { mineBlocks, depositToChest } from '../skills.js'
import { gotoGoal, inventoryIsFull, sleep } from '../utils.js'
import { goals } from '../pathfinder.js'

const DEFAULT_TARGETS = [
  'diamond_ore', 'deepslate_diamond_ore',
  'iron_ore', 'deepslate_iron_ore',
  'coal_ore', 'deepslate_coal_ore',
  'gold_ore', 'deepslate_gold_ore',
  'redstone_ore', 'deepslate_redstone_ore',
  'copper_ore', 'deepslate_copper_ore',
  'lapis_ore', 'deepslate_lapis_ore',
  'emerald_ore', 'deepslate_emerald_ore',
  'ancient_debris'
]

export default {
  name: 'miner',
  description: 'Sucht Erze, baut sie ab und lagert die Beute in Truhen',

  async tick (bot, ctx) {
    const targets = ctx.options.targets ?? DEFAULT_TARGETS
    const radius = ctx.options.searchRadius ?? 48

    if (inventoryIsFull(bot) && ctx.options.depositWhenFull !== false) {
      bot.say('Inventar voll - ich bringe die Beute weg.')
      const result = await depositToChest(bot, ctx.options.keep ?? ['diamond_pickaxe', 'iron_pickaxe', 'cooked_beef'])
      if (result.reason === 'keine_truhe') {
        ctx.log.warn('Keine Truhe gefunden, werfe billige Bloecke weg.')
        await dropJunk(bot)
      }
      return
    }

    const result = await mineBlocks(bot, targets, ctx.options.batchSize ?? 4, radius, (mined, block) => {
      ctx.log.info(`Abgebaut: ${block.name} (${mined})`)
    })

    if (result.reason === 'nichts_gefunden') {
      ctx.log.info('Keine Erze in Reichweite - grabe einen Stollen.')
      await digTunnel(bot, ctx)
      await sleep(1000)
    }
  }
}

const JUNK = ['cobblestone', 'cobbled_deepslate', 'diorite', 'andesite', 'granite', 'tuff', 'dirt', 'gravel', 'netherrack']

async function dropJunk (bot) {
  for (const name of JUNK) {
    const item = bot.inventory.items().find((entry) => entry.name === name)
    if (item) await bot.toss(item.type, null, item.count).catch(() => {})
  }
}

/** Gräbt eine Treppe nach unten, wenn die Wegfindung keinen Weg findet. */
async function digStaircaseDown (bot, steps = 4) {
  for (let i = 0; i < steps; i++) {
    const base = bot.entity.position.floored()
    const yaw = bot.entity.yaw
    const dx = Math.round(-Math.sin(yaw))
    const dz = Math.round(Math.cos(yaw))
    const targets = [base.offset(dx, -1, dz), base.offset(dx, 0, dz), base.offset(dx, 1, dz)]
    for (const position of targets) {
      const block = bot.blockAt(position)
      if (!block || block.name === 'air' || ['lava', 'water', 'bedrock'].includes(block.name)) continue
      try {
        if (bot.tool) await bot.tool.equipForBlock(block, {})
        await bot.dig(block)
      } catch {
        return
      }
    }
    await sleep(200)
  }
}

/** Gräbt einen geraden Stollen in Erzhoehe, um neue Chunks freizulegen. */
async function digTunnel (bot, ctx) {
  const targetY = ctx.options.tunnelY ?? -54
  const pos = bot.entity.position.floored()
  if (Math.abs(pos.y - targetY) > 3) {
    const reached = await gotoGoal(bot, new goals.GoalY(targetY), 60000).then(() => true).catch(() => false)
    if (!reached) await digStaircaseDown(bot, 4)
    return
  }
  const yaw = bot.entity.yaw
  const dx = Math.round(-Math.sin(yaw))
  const dz = Math.round(Math.cos(yaw))
  for (let i = 1; i <= 8; i++) {
    for (const dy of [0, 1]) {
      const block = bot.blockAt(pos.offset(dx * i, dy, dz * i))
      if (!block || block.name === 'air' || !bot.canDigBlock(block)) continue
      try {
        if (bot.tool) await bot.tool.equipForBlock(block, {})
        await bot.dig(block)
      } catch {
        return
      }
    }
  }
}
