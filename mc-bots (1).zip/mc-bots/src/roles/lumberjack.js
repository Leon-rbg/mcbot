import { chopTree, depositToChest, craftItem } from '../skills.js'
import { countItem, inventoryIsFull, sleep } from '../utils.js'

export default {
  name: 'lumberjack',
  description: 'Faellt Baeume, pflanzt Setzlinge nach und stellt Bretter/Stoecke her',

  async tick (bot, ctx) {
    if (inventoryIsFull(bot)) {
      const result = await depositToChest(bot, ctx.options.keep ?? ['iron_axe', 'diamond_axe', 'stone_axe'])
      ctx.log.info(`Abgeliefert: ${result.deposited} Gegenstaende (${result.reason})`)
      return
    }

    const result = await chopTree(bot, ctx.options.searchRadius ?? 64, ctx.options.replant !== false)
    if (result.reason === 'kein_baum') {
      ctx.log.info('Kein Baum in Reichweite - ich suche weiter.')
      await bot.wanderRandomly(48)
      await sleep(2000)
      return
    }
    if (result.chopped === 0) {
      ctx.log.info('Baum nicht erreichbar - ich suche einen anderen.')
      await bot.wanderRandomly(32)
      return
    }
    ctx.log.info(`${result.chopped} Holzbloecke gefaellt.`)

    if (ctx.options.craftPlanks !== false && countItem(bot, 'oak_log') >= 8) {
      await craftItem(bot, 'oak_planks', 4).catch(() => {})
    }
  }
}
