import { sleep } from '../utils.js'

export default {
  name: 'idle',
  description: 'Wartet auf Befehle im Chat und bleibt nur am Leben',

  async tick (bot, ctx) {
    await sleep(5000)
  }
}
