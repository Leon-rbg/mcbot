import { depositToChest } from '../skills.js'
import { goals } from '../pathfinder.js'
import { gotoGoal, sleep } from '../utils.js'

export default {
  name: 'storage',
  description: 'Sammelt herumliegende Items ein und sortiert alles in Truhen',

  async tick (bot, ctx) {
    const drop = bot.nearestEntity((entity) => entity.name === 'item' && entity.position.distanceTo(bot.entity.position) < (ctx.options.pickupRadius ?? 32))
    if (drop) {
      await gotoGoal(bot, new goals.GoalNear(drop.position.x, drop.position.y, drop.position.z, 1)).catch(() => {})
      await sleep(500)
      return
    }

    if (bot.inventory.items().length > (ctx.options.depositAfter ?? 8)) {
      const result = await depositToChest(bot, ctx.options.keep ?? [])
      ctx.log.info(`${result.deposited} Gegenstaende eingelagert (${result.reason}).`)
      if (result.reason === 'keine_truhe') await sleep(15000)
      return
    }

    await sleep(4000)
  }
}
