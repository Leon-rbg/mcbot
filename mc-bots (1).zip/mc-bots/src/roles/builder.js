import { build, withdrawFromChest } from '../skills.js'
import { countItem, sleep } from '../utils.js'

export default {
  name: 'builder',
  description: 'Baut Strukturen aus einem Bauplan (hut, wall, tower, platform)',

  async tick (bot, ctx) {
    const material = ctx.options.material ?? 'oak_planks'
    const blueprint = ctx.options.blueprint ?? 'hut'

    if (countItem(bot, material) < 8) {
      const result = await withdrawFromChest(bot, material, 64)
      if (result.withdrawn === 0) {
        if (!ctx.memory.waitingForMaterial) {
          ctx.log.warn(`Kein ${material} verfuegbar - warte auf Nachschub.`)
          ctx.memory.waitingForMaterial = true
        }
        await sleep(60000)
        return
      }
      ctx.memory.waitingForMaterial = false
    }

    const result = await build(bot, blueprint, material, ctx.memory.buildOrigin)
    ctx.log.info(`${result.placed} Bloecke gesetzt (${blueprint}, ${result.reason}).`)
    if (result.placed === 0) await sleep(10000)
  }
}
