import { craftItem, placeBlockNearby, smelt } from '../skills.js'
import { countItem, findBlock, itemByName, sleep } from '../utils.js'

export default {
  name: 'crafter',
  description: 'Arbeitet eine Crafting-Warteschlange ab und schmelzt Erze ein',

  async init (bot, ctx) {
    ctx.memory.queue = [...(ctx.options.queue ?? [])]
  },

  async tick (bot, ctx) {
    if (!findBlock(bot, 'crafting_table', 24) && itemByName(bot, 'crafting_table')) {
      await placeBlockNearby(bot, 'crafting_table').catch(() => {})
    }

    const job = ctx.memory.queue.shift()
    if (job) {
      try {
        await craftItem(bot, job.item, job.count ?? 1)
        ctx.log.info(`Hergestellt: ${job.count ?? 1}x ${job.item}`)
      } catch (err) {
        if (ctx.memory.lastFailure !== job.item) {
          ctx.log.warn(`${job.item}: ${err.message}`)
          ctx.memory.lastFailure = job.item
        }
        ctx.memory.queue.push(job)
        await sleep(60000)
      }
      return
    }

    // Standardarbeit: Roherze einschmelzen, wenn Brennstoff da ist.
    for (const ore of ['raw_iron', 'raw_gold', 'raw_copper']) {
      if (countItem(bot, ore) >= 4 && (countItem(bot, 'coal') > 0 || countItem(bot, 'charcoal') > 0)) {
        const fuel = countItem(bot, 'coal') > 0 ? 'coal' : 'charcoal'
        const smelted = await smelt(bot, ore, fuel, Math.min(8, countItem(bot, ore))).catch((err) => {
          ctx.log.warn(err.message)
          return 0
        })
        if (smelted) ctx.log.info(`${smelted}x ${ore} eingeschmolzen.`)
        return
      }
    }

    await sleep(8000)
  }
}
