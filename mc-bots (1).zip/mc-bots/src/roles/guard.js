import { goals } from '../pathfinder.js'
import { gotoGoal, sleep } from '../utils.js'

const HOSTILE = new Set([
  'zombie', 'husk', 'drowned', 'zombie_villager', 'skeleton', 'stray', 'bogged', 'wither_skeleton',
  'creeper', 'spider', 'cave_spider', 'enderman', 'witch', 'slime', 'magma_cube', 'blaze',
  'pillager', 'vindicator', 'evoker', 'ravager', 'phantom', 'silverfish', 'endermite',
  'zombified_piglin', 'piglin', 'piglin_brute', 'hoglin', 'zoglin', 'guardian', 'elder_guardian',
  'shulker', 'vex', 'warden', 'breeze', 'creaking'
])

export default {
  name: 'guard',
  description: 'Bewacht einen Bereich, greift feindliche Mobs an und kehrt zum Posten zurueck',

  async init (bot, ctx) {
    ctx.memory.post = bot.entity.position.clone()
    bot.on('entityHurt', (entity) => {
      if (entity === bot.entity && bot.pvp && !bot.pvp.target) {
        const attacker = nearestHostile(bot, ctx.options.radius ?? 20, ctx.options.hostilesOnly !== false)
        if (attacker) bot.pvp.attack(attacker)
      }
    })
  },

  async tick (bot, ctx) {
    const radius = ctx.options.radius ?? 20
    const target = nearestHostile(bot, radius, ctx.options.hostilesOnly !== false)

    if (target) {
      if (bot.pvp.target !== target) {
        ctx.log.info(`Greife ${target.name ?? target.displayName} an.`)
        bot.pvp.attack(target)
      }
      await sleep(500)
      return
    }

    if (bot.pvp.target) bot.pvp.stop()

    const post = ctx.memory.post
    if (post && bot.entity.position.distanceTo(post) > 6) {
      await gotoGoal(bot, new goals.GoalNear(post.x, post.y, post.z, 2)).catch(() => {})
    }
    await sleep(1000)
  }
}

function nearestHostile (bot, radius, hostilesOnly) {
  return bot.nearestEntity((entity) => {
    if (entity === bot.entity || !entity.position) return false
    if (entity.position.distanceTo(bot.entity.position) > radius) return false
    if (entity.type === 'player') return !hostilesOnly && entity.username !== bot.state.master
    return HOSTILE.has(entity.name)
  })
}
