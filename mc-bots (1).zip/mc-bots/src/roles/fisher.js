import { goals } from '../pathfinder.js'
import { craftItem, depositToChest, fish } from '../skills.js'
import { findBlock, gotoGoal, inventoryIsFull, itemByName, sleep } from '../utils.js'

export default {
  name: 'fisher',
  description: 'Angelt am naechsten Gewaesser und lagert den Fang ein',

  async tick (bot, ctx) {
    if (inventoryIsFull(bot)) {
      await depositToChest(bot, ctx.options.keep ?? ['fishing_rod'])
      return
    }

    if (!itemByName(bot, 'fishing_rod')) {
      ctx.log.info('Keine Angel - versuche eine zu craften.')
      const crafted = await craftItem(bot, 'fishing_rod', 1).catch((err) => {
        ctx.log.warn(err.message)
        return 0
      })
      if (!crafted) {
        ctx.log.info('Warte auf eine Angel (Truhe oder per Befehl geben).')
        await sleep(60000)
        return
      }
    }

    const water = findBlock(bot, 'water', ctx.options.searchRadius ?? 48)
    if (!water) {
      ctx.log.info('Kein Wasser gefunden - ich suche weiter.')
      await bot.wanderRandomly(64)
      return
    }

    if (bot.entity.position.distanceTo(water.position) > 4) {
      await gotoGoal(bot, new goals.GoalNear(water.position.x, water.position.y + 1, water.position.z, 2)).catch(() => {})
    }
    await bot.lookAt(water.position, true)
    const caught = await fish(bot, 3).catch((err) => {
      ctx.log.warn(err.message)
      return 0
    })
    if (caught > 0) ctx.log.info(`${caught}x geangelt.`)
  }
}
