import { goals } from '../pathfinder.js'
import { findBlock, gotoGoal, randomInt, sleep } from '../utils.js'

const INTERESTING = ['chest', 'spawner', 'diamond_ore', 'ancient_debris', 'end_portal_frame', 'bell', 'enchanting_table']

export default {
  name: 'explorer',
  description: 'Erkundet die Welt, meldet Fundorte und kartiert Biome',

  async init (bot, ctx) {
    ctx.memory.finds = []
  },

  async tick (bot, ctx) {
    const step = ctx.options.stepDistance ?? 64
    const pos = bot.entity.position
    const angle = Math.random() * Math.PI * 2
    const target = pos.offset(Math.cos(angle) * step, 0, Math.sin(angle) * step).floored()

    ctx.log.info(`Erkunde Richtung ${target.x} / ${target.z}`)
    await gotoGoal(bot, new goals.GoalNearXZ(target.x, target.z, 8)).catch((err) => {
      ctx.log.warn(`Weg blockiert: ${err.message}`)
    })

    for (const name of INTERESTING) {
      const block = findBlock(bot, name, 32)
      if (!block) continue
      const key = `${name}@${block.position}`
      if (ctx.memory.finds.includes(key)) continue
      ctx.memory.finds.push(key)
      const message = `Fund: ${name} bei ${block.position.x} ${block.position.y} ${block.position.z}`
      ctx.log.info(message)
      bot.say(message)
    }

    await sleep(randomInt(1000, 3000))
  }
}
