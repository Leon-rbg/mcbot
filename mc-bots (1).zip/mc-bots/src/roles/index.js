import builder from './builder.js'
import crafter from './crafter.js'
import explorer from './explorer.js'
import farmer from './farmer.js'
import fisher from './fisher.js'
import follower from './follower.js'
import guard from './guard.js'
import idle from './idle.js'
import lumberjack from './lumberjack.js'
import miner from './miner.js'
import storage from './storage.js'

export const roles = {
  builder,
  crafter,
  explorer,
  farmer,
  fisher,
  follower,
  guard,
  idle,
  lumberjack,
  miner,
  storage
}

export function getRole (name) {
  return roles[name] ?? roles.idle
}

export function roleNames () {
  return Object.keys(roles)
}
