import { goals } from '../pathfinder.js'
import { harvestCrops, depositToChest } from '../skills.js'
import { findBlock, findBlocks, gotoGoal, inventoryIsFull, itemByName, sleep } from '../utils.js'

export default {
  name: 'farmer',
  description: 'Erntet reife Feldfruechte, saet neu aus und fuellt Truhen auf',

  async tick (bot, ctx) {
    if (inventoryIsFull(bot)) {
      await depositToChest(bot, ctx.options.keep ?? ['wheat_seeds', 'carrot', 'potato', 'beetroot_seeds', 'iron_hoe'])
      return
    }

    const result = await harvestCrops(
      bot,
      ctx.options.crops ?? ['wheat', 'carrots', 'potatoes', 'beetroots'],
      ctx.options.searchRadius ?? 32,
      ctx.options.replant !== false
    )

    if (result.harvested > 0) {
      ctx.log.info(`${result.harvested} Pflanzen geerntet.`)
      return
    }

    // Nichts reif: Bonemeal einsetzen oder freies Ackerland bepflanzen.
    if (await useBonemeal(bot, ctx)) return
    if (await plantOnEmptyFarmland(bot, ctx)) return
    await sleep(5000)
  }
}

async function useBonemeal (bot, ctx) {
  const bonemeal = itemByName(bot, 'bone_meal')
  if (!bonemeal) return false
  const crop = findBlock(bot, ctx.options.crops ?? ['wheat', 'carrots', 'potatoes', 'beetroots'], 16)
  if (!crop) return false
  try {
    await bot.equip(bonemeal, 'hand')
    await bot.activateBlock(crop)
    return true
  } catch {
    return false
  }
}

async function plantOnEmptyFarmland (bot, ctx) {
  const farmland = findBlocks(bot, 'farmland', ctx.options.searchRadius ?? 32, 32)
    .find((block) => bot.blockAt(block.position.offset(0, 1, 0))?.name === 'air')
  if (!farmland) return false
  const seed = ['wheat_seeds', 'carrot', 'potato', 'beetroot_seeds']
    .map((name) => itemByName(bot, name))
    .find(Boolean)
  if (!seed) return false
  try {
    await gotoGoal(bot, new goals.GoalNear(
      farmland.position.x, farmland.position.y, farmland.position.z, 2
    ))
    await bot.equip(seed, 'hand')
    await bot.placeBlock(farmland, { x: 0, y: 1, z: 0 })
    return true
  } catch {
    return false
  }
}
