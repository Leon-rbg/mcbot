import { goals } from './pathfinder.js'
import Vec3 from 'vec3'
import { getRole, roleNames } from './roles/index.js'
import {
  build,
  chopTree,
  craftItem,
  depositToChest,
  fish,
  harvestCrops,
  mineBlocks,
  placeBlockNearby,
  sleepInBed,
  smelt,
  stopAll,
  tossItem,
  withdrawFromChest
} from './skills.js'
import { countItem, describeInventory, execContext, gotoGoal, itemByName, nearestPlayerEntity } from './utils.js'

/**
 * Chat-Befehle. Jeder Eintrag: { args, help, masterOnly, run(bot, ctx) }
 * ctx = { args, sender, reply, log, setRole }
 */
export const commands = {
  hilfe: {
    aliases: ['help', '?'],
    help: 'Zeigt alle Befehle',
    public: true,
    run (bot, { reply }) {
      const names = Object.keys(commands)
      reply(`Befehle: ${names.join(', ')}`)
    }
  },

  status: {
    help: 'Leben, Hunger, Position und aktuelle Rolle',
    public: true,
    run (bot, { reply }) {
      const pos = bot.entity.position.floored()
      reply(`Rolle=${bot.state.roleName} HP=${Math.round(bot.health)} Hunger=${Math.round(bot.food)} Pos=${pos.x}/${pos.y}/${pos.z} Modus=${bot.state.manual ? 'manuell' : 'automatisch'}`)
    }
  },

  rolle: {
    aliases: ['role'],
    help: '<rolle> - wechselt die Aufgabe (' + roleNames().join('/') + ')',
    masterOnly: true,
    async run (bot, { args, reply }) {
      const name = args[0]
      if (!name || !roleNames().includes(name)) return reply(`Unbekannte Rolle. Moeglich: ${roleNames().join(', ')}`)
      await bot.setRole(name)
      reply(`Neue Rolle: ${name}`)
    }
  },

  komm: {
    aliases: ['come', 'hierher'],
    help: 'Kommt zum Absender',
    async run (bot, { sender, reply }) {
      const entity = nearestPlayerEntity(bot, sender)
      if (!entity) return reply('Ich sehe dich nicht.')
      bot.state.manual = true
      reply('Bin unterwegs.')
      await gotoGoal(bot, new goals.GoalNear(entity.position.x, entity.position.y, entity.position.z, 2))
      reply('Angekommen.')
    }
  },

  folge: {
    aliases: ['follow'],
    help: '[spieler] - folgt dir oder einem Spieler',
    async run (bot, { args, sender, reply }) {
      const target = args[0] ?? sender
      const entity = nearestPlayerEntity(bot, target)
      if (!entity) return reply(`${target} ist nicht in Sichtweite.`)
      bot.state.manual = true
      bot.pathfinder.setGoal(new goals.GoalFollow(entity, 3), true)
      reply(`Folge ${target}.`)
    }
  },

  stopp: {
    aliases: ['stop', 'halt'],
    help: 'Bricht alles ab und wartet',
    run (bot, { reply }) {
      bot.state.manual = true
      stopAll(bot)
      reply('Gestoppt.')
    }
  },

  weiter: {
    aliases: ['resume', 'auto'],
    help: 'Setzt die automatische Rolle fort',
    run (bot, { reply }) {
      bot.state.manual = false
      reply(`Mache weiter als ${bot.state.roleName}.`)
    }
  },

  geh: {
    aliases: ['goto'],
    help: '<x> <y> <z> - laeuft zu Koordinaten',
    async run (bot, { args, reply }) {
      const [x, y, z] = args.map(Number)
      if ([x, y, z].some(Number.isNaN)) return reply('Nutzung: geh <x> <y> <z>')
      bot.state.manual = true
      reply(`Laufe nach ${x}/${y}/${z}.`)
      await gotoGoal(bot, new goals.GoalBlock(x, y, z))
      reply('Angekommen.')
    }
  },

  abbauen: {
    aliases: ['mine'],
    help: '<block> [anzahl] - baut Bloecke ab',
    async run (bot, { args, reply }) {
      const name = args[0]
      const count = Number(args[1] ?? 1)
      if (!name) return reply('Nutzung: abbauen <block> [anzahl]')
      bot.state.manual = true
      reply(`Baue ${count}x ${name} ab.`)
      const result = await mineBlocks(bot, [name], count, 64)
      reply(`Fertig: ${result.mined}x ${name} (${result.reason}).`)
    }
  },

  holz: {
    aliases: ['chop', 'faellen'],
    help: '[anzahl baeume] - faellt Baeume',
    async run (bot, { args, reply }) {
      const trees = Number(args[0] ?? 1)
      bot.state.manual = true
      let total = 0
      for (let i = 0; i < trees; i++) {
        const result = await chopTree(bot, 64, true)
        total += result.chopped
        if (result.reason === 'kein_baum') break
      }
      reply(`${total} Holzbloecke gesammelt.`)
    }
  },

  ernten: {
    aliases: ['harvest', 'farm'],
    help: 'Erntet reife Feldfruechte in der Naehe',
    async run (bot, { reply }) {
      bot.state.manual = true
      const result = await harvestCrops(bot)
      reply(`${result.harvested} Pflanzen geerntet (${result.reason}).`)
    }
  },

  bauen: {
    aliases: ['build'],
    help: '<hut|wall|tower|platform> [material] - baut eine Struktur',
    async run (bot, { args, reply }) {
      const blueprint = args[0] ?? 'hut'
      const material = args[1] ?? 'oak_planks'
      bot.state.manual = true
      reply(`Baue ${blueprint} aus ${material}.`)
      const result = await build(bot, blueprint, material)
      reply(`${result.placed} Bloecke gesetzt (${result.reason}).`)
    }
  },

  craft: {
    aliases: ['herstellen'],
    help: '<item> [anzahl] - stellt etwas her',
    async run (bot, { args, reply }) {
      const name = args[0]
      const count = Number(args[1] ?? 1)
      if (!name) return reply('Nutzung: craft <item> [anzahl]')
      try {
        await craftItem(bot, name, count)
        reply(`${count}x ${name} hergestellt.`)
      } catch (err) {
        reply(`Geht nicht: ${err.message}`)
      }
    }
  },

  schmelzen: {
    aliases: ['smelt'],
    help: '<item> [brennstoff] [anzahl] - schmelzt im Ofen',
    async run (bot, { args, reply }) {
      const [input, fuel = 'coal', count = '1'] = args
      if (!input) return reply('Nutzung: schmelzen <item> [brennstoff] [anzahl]')
      try {
        const done = await smelt(bot, input, fuel, Number(count))
        reply(`${done}x ${input} geschmolzen.`)
      } catch (err) {
        reply(`Geht nicht: ${err.message}`)
      }
    }
  },

  angeln: {
    aliases: ['fish'],
    help: '[anzahl] - angelt',
    async run (bot, { args, reply }) {
      bot.state.manual = true
      const caught = await fish(bot, Number(args[0] ?? 1)).catch((err) => {
        reply(err.message)
        return 0
      })
      if (caught) reply(`${caught}x geangelt.`)
    }
  },

  schlafen: {
    aliases: ['sleep'],
    help: 'Sucht ein Bett und schlaeft',
    async run (bot, { reply }) {
      reply(await sleepInBed(bot))
    }
  },

  inventar: {
    aliases: ['inv', 'inventory'],
    help: 'Zeigt das Inventar',
    run (bot, { reply }) {
      reply(describeInventory(bot))
    }
  },

  gib: {
    aliases: ['toss', 'drop'],
    help: '<item> [anzahl] - wirft Gegenstaende ab',
    async run (bot, { args, sender, reply }) {
      const name = args[0]
      if (!name) return reply('Nutzung: gib <item> [anzahl]')
      const entity = nearestPlayerEntity(bot, sender)
      if (entity) {
        await gotoGoal(bot, new goals.GoalNear(entity.position.x, entity.position.y, entity.position.z, 2)).catch(() => {})
        await bot.lookAt(entity.position, true)
      }
      try {
        await tossItem(bot, name, args[1] ? Number(args[1]) : null)
        reply(`${name} abgeworfen.`)
      } catch (err) {
        reply(err.message)
      }
    }
  },

  einlagern: {
    aliases: ['deposit'],
    help: 'Legt alles in die naechste Truhe',
    async run (bot, { reply }) {
      const result = await depositToChest(bot, [])
      reply(`${result.deposited} Gegenstaende eingelagert (${result.reason}).`)
    }
  },

  holen: {
    aliases: ['withdraw'],
    help: '<item> [anzahl] - holt Gegenstaende aus der Truhe',
    async run (bot, { args, reply }) {
      const name = args[0]
      if (!name) return reply('Nutzung: holen <item> [anzahl]')
      const result = await withdrawFromChest(bot, name, Number(args[1] ?? 1))
      reply(`${result.withdrawn}x ${name} geholt (${result.reason}).`)
    }
  },

  setze: {
    aliases: ['place'],
    help: '<block> - setzt einen Block neben sich',
    async run (bot, { args, reply }) {
      try {
        await placeBlockNearby(bot, args[0])
        reply(`${args[0]} gesetzt.`)
      } catch (err) {
        reply(err.message)
      }
    }
  },

  angriff: {
    aliases: ['attack', 'kill'],
    help: '<spieler|mob> - greift ein Ziel an',
    masterOnly: true,
    async run (bot, { args, reply }) {
      const name = args[0]
      if (!name) return reply('Nutzung: angriff <spieler|mob>')
      const entity = bot.nearestEntity((candidate) =>
        candidate.username === name || candidate.name === name)
      if (!entity) return reply(`${name} nicht gefunden.`)
      bot.state.manual = true
      bot.pvp.attack(entity)
      reply(`Greife ${name} an.`)
    }
  },

  ausruesten: {
    aliases: ['equip'],
    help: '<item> [hand|off-hand|head|torso|legs|feet]',
    async run (bot, { args, reply }) {
      const item = itemByName(bot, args[0])
      if (!item) return reply(`${args[0]} nicht im Inventar.`)
      await bot.equip(item, args[1] ?? 'hand')
      reply(`${args[0]} ausgeruestet.`)
    }
  },

  benutzen: {
    aliases: ['use', 'activate'],
    help: 'Benutzt den Gegenstand in der Hand',
    async run (bot, { reply }) {
      bot.activateItem()
      setTimeout(() => bot.deactivateItem(), 1000)
      reply('Benutzt.')
    }
  },

  sag: {
    aliases: ['say'],
    help: '<text> - schreibt in den Chat',
    masterOnly: true,
    run (bot, { args }) {
      bot.chat(args.join(' '))
    }
  },

  zaehle: {
    aliases: ['count'],
    help: '<item> - zaehlt Gegenstaende im Inventar',
    run (bot, { args, reply }) {
      reply(`${args[0]}: ${countItem(bot, args[0])}`)
    }
  },

  merke: {
    aliases: ['mark'],
    help: '<name> - merkt sich die aktuelle Position',
    run (bot, { args, reply }) {
      const name = args[0] ?? 'home'
      bot.state.waypoints[name] = bot.entity.position.clone()
      reply(`Wegpunkt "${name}" gespeichert.`)
    }
  },

  zu: {
    aliases: ['waypoint'],
    help: '<name> - laeuft zu einem gemerkten Wegpunkt',
    async run (bot, { args, reply }) {
      const point = bot.state.waypoints[args[0] ?? 'home']
      if (!point) return reply('Wegpunkt unbekannt.')
      bot.state.manual = true
      await gotoGoal(bot, new goals.GoalNear(point.x, point.y, point.z, 1))
      reply('Angekommen.')
    }
  },

  respawn: {
    help: 'Respawnt nach dem Tod',
    run (bot, { reply }) {
      bot.respawn()
      reply('Respawne.')
    }
  },

  tschuess: {
    aliases: ['quit', 'leave'],
    help: 'Verlaesst den Server',
    masterOnly: true,
    run (bot, { reply }) {
      reply('Bis dann!')
      bot.state.shuttingDown = true
      setTimeout(() => bot.quit('Befehl'), 500)
    }
  }
}

const aliasMap = buildAliasMap()

function buildAliasMap () {
  const map = new Map()
  for (const [name, command] of Object.entries(commands)) {
    map.set(name, command)
    for (const alias of command.aliases ?? []) map.set(alias, command)
  }
  return map
}

export function resolveCommand (name) {
  return aliasMap.get(name.toLowerCase())
}

export function positionFromArgs (args) {
  const [x, y, z] = args.map(Number)
  return new Vec3(x, y, z)
}

/** Fuehrt einen Chat-Befehl aus; kapselt Fehler, damit der Bot nicht abstuerzt. */
export async function handleCommand (bot, sender, rawMessage) {
  const parts = rawMessage.trim().split(/\s+/)
  const name = parts.shift()
  const command = resolveCommand(name)
  const reply = (text) => bot.whisperOrSay(sender, text)

  if (!command) {
    reply(`Unbekannter Befehl "${name}". Schreib ${bot.state.chatPrefix}hilfe`)
    return
  }
  const needsMaster = command.masterOnly || !(command.public || bot.state.allowPublicCommands)
  if (needsMaster && sender !== bot.state.master) {
    reply('Das darf nur mein Besitzer.')
    return
  }

  bot.state.log.info(`Befehl von ${sender}: ${rawMessage}`)
  bot.state.commandRunning = (bot.state.commandRunning ?? 0) + 1
  try {
    await execContext.run({ command: true }, () =>
      command.run(bot, { args: parts, sender, reply, log: bot.state.log })
    )
  } catch (err) {
    bot.state.log.error(`Befehl "${name}" fehlgeschlagen:`, err.message)
    reply(`Fehler: ${err.message}`)
  } finally {
    bot.state.commandRunning = Math.max(0, (bot.state.commandRunning ?? 1) - 1)
  }
}

export function getRoleFor (name) {
  return getRole(name)
}
