import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { createManagedBot } from './src/botFactory.js'
import { roleNames } from './src/roles/index.js'
import { sleep } from './src/utils.js'

const here = path.dirname(fileURLToPath(import.meta.url))

function parseArgs (argv) {
  const args = { only: null, host: null, port: null, version: null, config: 'config.json' }
  for (let i = 2; i < argv.length; i++) {
    const [key, value] = argv[i].replace(/^--/, '').split('=')
    if (value !== undefined) args[key] = value
    else if (argv[i].startsWith('--')) args[key] = argv[++i]
  }
  return args
}

function loadConfig (file) {
  const configPath = path.isAbsolute(file) ? file : path.join(here, file)
  return JSON.parse(fs.readFileSync(configPath, 'utf8'))
}

async function main () {
  const args = parseArgs(process.argv)
  const config = loadConfig(args.config)

  if (args.host) config.server.host = args.host
  if (args.port) config.server.port = Number(args.port)
  if (args.version) config.server.version = args.version
  if (process.env.MC_HOST) config.server.host = process.env.MC_HOST
  if (process.env.MC_PORT) config.server.port = Number(process.env.MC_PORT)
  if (process.env.MC_MASTER) config.master = process.env.MC_MASTER

  let bots = config.bots
  if (args.only) {
    const wanted = String(args.only).split(',')
    bots = bots.filter((bot) => wanted.includes(bot.username) || wanted.includes(bot.role))
    if (bots.length === 0) {
      console.error(`Kein Bot passt zu "--only ${args.only}". Verfuegbar: ${config.bots.map((b) => `${b.username}(${b.role})`).join(', ')}`)
      process.exit(1)
    }
  }

  console.log(`Server: ${config.server.host}:${config.server.port} (Version ${config.server.version}, ${config.server.auth})`)
  console.log(`Besitzer: ${config.master} | Chat-Prefix: ${config.chatPrefix}`)
  console.log(`Rollen verfuegbar: ${roleNames().join(', ')}`)
  console.log(`Starte ${bots.length} Bot(s): ${bots.map((b) => `${b.username}=${b.role}`).join(', ')}`)

  const managers = []
  let webPort = config.webInventory?.startPort ?? 3010

  for (const botConfig of bots) {
    const manager = createManagedBot(botConfig, config)
    if (config.webInventory?.enabled) manager.webPort = webPort++
    managers.push(manager)
    manager.start()
    // Gestaffelt verbinden, damit der Server die Logins nicht als Flood wertet.
    await sleep(config.spawnDelayMs ?? 6000)
  }

  const shutdown = () => {
    console.log('\nBeende alle Bots ...')
    for (const manager of managers) manager.stop()
    setTimeout(() => process.exit(0), 1500)
  }
  process.on('SIGINT', shutdown)
  process.on('SIGTERM', shutdown)
}

main().catch((err) => {
  console.error('Startfehler:', err)
  process.exit(1)
})
