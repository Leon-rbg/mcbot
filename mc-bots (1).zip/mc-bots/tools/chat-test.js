// Kleiner Testclient: loggt sich ein, schickt Chat-Befehle und protokolliert Antworten.
import mineflayer from 'mineflayer'

const [, , host = 'serverplayer1235.aternos.me', port = '12490', username = 'Leon_Test', ...messages] = process.argv

const bot = mineflayer.createBot({ host, port: Number(port), username, auth: 'offline', version: '26.1' })

bot.on('messagestr', (message) => console.log('CHAT:', message))
bot.once('spawn', async () => {
  console.log('Testclient verbunden als', bot.username)
  for (const message of messages) {
    await new Promise((resolve) => setTimeout(resolve, 4000))
    console.log('SENDE:', message)
    bot.chat(message)
  }
  setTimeout(() => bot.quit('fertig'), 15000)
})
bot.on('error', (err) => console.error('Testclient Fehler:', err.message))
