# Minecraft Bot-Schwarm (Mineflayer, Java 26.1, Cracked/Offline)

Mehrere Mineflayer-Bots mit unterschiedlichen Aufgaben fuer den Server
`serverplayer1235.aternos.me:12490` (Paper 26.1, Protokoll 775, Offline-Login).

Jeder Bot nutzt den kompletten Mineflayer-Stack: Wegfindung, Kampf, Abbauen,
Bauen, Crafting, Oefen, Truhen, Angeln, Schlafen, Ruestung, Auto-Essen und
ein Web-Inventar zum Zuschauen.

## Installation

```bash
cd mc-bots
npm install
```

Node.js 18+ wird benoetigt (getestet mit Node 24).

## Start

```bash
npm start                       # alle Bots aus config.json
node index.js --only Miner_Max  # nur ein Bot
node index.js --only miner,guard    # nur bestimmte Rollen
node index.js --host andere.ip --port 25565 --version 26.1
```

Alternativ per Umgebungsvariablen: `MC_HOST`, `MC_PORT`, `MC_MASTER`.

Wichtig: Trage in `config.json` bei `"master"` deinen Minecraft-Namen ein,
sonst funktionieren die Besitzer-Befehle (`rolle`, `angriff`, `sag`, `tschuess`)
nicht.

## Bots und Rollen

| Bot | Rolle | Aufgabe |
| --- | --- | --- |
| Miner_Max | `miner` | Sucht und baut Erze ab, graebt Stollen auf Y=-54, lagert Beute ein |
| Holzi_Hans | `lumberjack` | Faellt ganze Baeume, pflanzt Setzlinge nach, craftet Bretter |
| Farmer_Fritz | `farmer` | Erntet reifes Getreide, saet nach, nutzt Knochenmehl |
| Wache_Wilma | `guard` | Bewacht den Postenbereich, greift feindliche Mobs an |
| Bauer_Bob | `builder` | Baut Strukturen (`hut`, `wall`, `tower`, `platform`) |
| Angler_Anna | `fisher` | Angelt am naechsten Gewaesser, craftet sich notfalls eine Angel |
| Scout_Sam | `explorer` | Erkundet die Welt und meldet Truhen, Spawner, Erze im Chat |
| Lager_Lena | `storage` | Sammelt Drops ein und sortiert sie in Truhen |
| Crafter_Cleo | `crafter` | Arbeitet eine Crafting-Liste ab und schmelzt Roherze |
| Buddy_Ben | `follower` | Folgt dir, verteidigt dich |

Zusaetzlich gibt es die Rolle `idle` (wartet nur auf Befehle).

## Chat-Steuerung

Prefix ist `!` (in `config.json` aenderbar). Befehle funktionieren im
oeffentlichen Chat und per `/msg <bot> <befehl>`.

* An alle Bots: `!status`
* An einen Bot: `!@Miner_Max status`
* An alle (explizit): `!@alle weiter`

| Befehl | Wirkung |
| --- | --- |
| `hilfe` | Liste aller Befehle |
| `status` | Rolle, Leben, Hunger, Position |
| `rolle <name>` | Aufgabe wechseln (nur Besitzer) |
| `komm` / `folge [spieler]` | Zu dir kommen / folgen |
| `stopp` / `weiter` | Manuell anhalten / Automatik fortsetzen |
| `geh <x> <y> <z>` | Zu Koordinaten laufen |
| `abbauen <block> [anzahl]` | Bloecke abbauen und einsammeln |
| `holz [anzahl]` | Baeume faellen |
| `ernten` | Felder abernten |
| `bauen <hut\|wall\|tower\|platform> [material]` | Struktur bauen |
| `craft <item> [anzahl]` | Herstellen (nutzt Werkbank) |
| `schmelzen <item> [brennstoff] [anzahl]` | Ofen benutzen |
| `angeln [anzahl]` | Angeln |
| `schlafen` | Bett suchen und schlafen |
| `inventar` / `zaehle <item>` | Inventar anzeigen / zaehlen |
| `gib <item> [anzahl]` | Items zu dir bringen und abwerfen |
| `einlagern` / `holen <item> [anzahl]` | Truhen benutzen |
| `setze <block>` | Block platzieren |
| `ausruesten <item> [slot]` | Ausruesten |
| `benutzen` | Gegenstand in der Hand benutzen |
| `angriff <ziel>` | Ziel angreifen (nur Besitzer) |
| `merke <name>` / `zu <name>` | Wegpunkte setzen und anlaufen |
| `sag <text>` | Bot schreibt im Chat (nur Besitzer) |
| `respawn` / `tschuess` | Respawnen / Server verlassen |

Englische Aliase (`help`, `come`, `follow`, `stop`, `goto`, `mine`, `chop`,
`build`, `attack`, ...) funktionieren ebenfalls.

## Automatik

* **Auto-Reconnect** mit steigender Wartezeit (Aternos-Neustarts, Kicks).
* **Auto-Essen** ab Hunger < 15 (schlechte Nahrung ist gesperrt).
* **Auto-Ruestung**: beste gefundene Ruestung wird angezogen.
* **Auto-Schlafen** nachts, wenn ein Bett in 16 Bloecken Reichweite ist.
* **Anti-AFK**: kleine Bewegungen, wenn nichts zu tun ist.
* **Rueckzug** bei weniger als 8 Herzpunkten Leben.
* **Web-Inventar** pro Bot auf Port 3010, 3011, ... (`webInventory.enabled: true` setzen;
  standardmaessig aus, weil es bei 10 Bots zusaetzlichen Speicher kostet).

## Konfiguration

Alles steckt in `config.json`: Server, Besitzer, Chat-Prefix, Reconnect,
Web-Inventar, Startverzoegerung und die Bot-Liste mit Rolle und Optionen
(z. B. Erzliste des Miners, Bauplan des Builders, Crafting-Queue des Crafters).

Wichtige Schalter:

* `server.viewDistance` (Standard `"tiny"`): kleine Sichtweite spart viel RAM.
  Bei 10 Bots in einem Prozess sonst schnell >2 GB und Absturz.
* `allowPublicCommands` (Standard `false`): nur der Besitzer darf Befehle geben;
  `hilfe` und `status` bleiben fuer alle offen.
* `npm start` startet Node mit `--max-old-space-size=4096`.

Neue Rolle hinzufuegen: Datei in `src/roles/` anlegen mit
`export default { name, description, init?, tick }` und in
`src/roles/index.js` eintragen.

## Testwerkzeug

```bash
node tools/chat-test.js serverplayer1235.aternos.me 12490 DeinName "!status" "!@Miner_Max inventar"
```

Loggt sich als normaler Spieler ein, schickt Befehle und zeigt die Antworten.

## Hinweise

* Offline-/Cracked-Login (`auth: "offline"`) ist voreingestellt.
* Bots starten gestaffelt (`spawnDelayMs`), damit Aternos die Logins nicht als
  Flood wertet; mehr als ~10 Bots sprengen das Slot-Limit des Servers.
* Ohne Werkzeug im Inventar arbeitet der Miner sehr langsam — gib den Bots
  Spitzhacken/Aexte (`gib`-Befehl oder Truhe in der Naehe des Startpunkts).
